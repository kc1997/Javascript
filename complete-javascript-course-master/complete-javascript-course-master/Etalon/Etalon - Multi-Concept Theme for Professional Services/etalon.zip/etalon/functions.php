<?php
/**
 * etalon functions file
 *
 * @package etalon
 * by KeyDesign
 */

 require_once( get_template_directory() . '/core/init.php');

 // -------------------------------------
 // Edit below this line
 // -------------------------------------